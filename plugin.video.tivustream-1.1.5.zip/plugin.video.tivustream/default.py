# -*- coding: utf-8 -*-
#!/usr/bin/python
# -*- coding: latin-1 -*-

import sys, xpath, xbmc, os

if os.path.exists("/usr/lib/enigma2/python/Plugins/Extensions/KodiLite"): # enigma2 KodiLite
    libs = sys.argv[0].replace("default.py", "resources/lib")
    if os.path.exists(libs):
       sys.path.append(libs)
    print "Here in default-py sys.argv =", sys.argv
    if ("?plugin%3A%2F%2F" in sys.argv[2]) or ("?plugin://" in sys.argv[2]):
        argtwo = sys.argv[2]
        n2 = argtwo.find("?", 0)
        n3 = argtwo.find("?", (n2+2))
        if n3<0: 
            sys.argv[0] = argtwo
            sys.argv[2] = ""
        else:
            sys.argv[0] = argtwo[:n3]
            sys.argv[2] = argtwo[n3:]
        sys.argv[0] = sys.argv[0].replace("?", "")

    else:
        sys.argv[0] = sys.argv[0].replace('/usr/lib/enigma2/python/Plugins/Extensions/KodiLite/plugins/', 'plugin://') 
        sys.argv[0] = sys.argv[0].replace('default.py', '')
    print "Here in default-py sys.argv B=", sys.argv

"""
Copyright (C) 2019
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>
############################################################
Developed by Lululla for TiVuStream.com
Thank's @MasterG & @pcd for all (Linuxsat support)
"""

import urllib, urllib2, sys, re, os, unicodedata, json
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import xbmcvfs,socket,urlparse,time,threading,HTMLParser
import os, re             
import base64

PLUGIN_NAME = "tivustream"                            
plugin_handle = int(sys.argv[1])


mysettings = xbmcaddon.Addon(id="plugin.video." + PLUGIN_NAME)
# __language__ = mysettings.get_string


profile = mysettings.getAddonInfo('profile')
home = mysettings.getAddonInfo('path')
artfolder = (home + '/resources/img/')
fanart2 = xbmc.translatePath(os.path.join(home, 'fanart2.png'))
fanart = xbmc.translatePath(os.path.join(home, 'fanart.jpg'))
icon = xbmc.translatePath(os.path.join(home, 'icon.png'))
#############################
f_events = xbmc.translatePath(os.path.join(artfolder, 'events.jpg'))
f_free = xbmc.translatePath(os.path.join(artfolder, 'free.jpg'))
f_sport = xbmc.translatePath(os.path.join(artfolder, 'sport.jpg'))
f_media = xbmc.translatePath(os.path.join(artfolder, 'media.jpg'))
f_series = xbmc.translatePath(os.path.join(artfolder, 'series.jpg'))
f_fiction = xbmc.translatePath(os.path.join(artfolder, 'fiction.jpg'))
f_media_60_90 = xbmc.translatePath(os.path.join(artfolder, 'media_60_90.jpg'))
f_music = xbmc.translatePath(os.path.join(artfolder, 'music.jpg'))
f_news = xbmc.translatePath(os.path.join(artfolder, 'news.jpg'))
f_radio = xbmc.translatePath(os.path.join(artfolder, 'radio.jpg'))
f_int = xbmc.translatePath(os.path.join(artfolder, 'int.jpg'))
f_mediaint = xbmc.translatePath(os.path.join(artfolder, 'mediaint.jpg'))
f_seriesint = xbmc.translatePath(os.path.join(artfolder, 'series.png'))
f_radioint = xbmc.translatePath(os.path.join(artfolder, 'radioint.jpg'))

f_search = xbmc.translatePath(os.path.join(artfolder, 'search.jpg'))
##############################3
i_events = xbmc.translatePath(os.path.join(artfolder, 'events.png'))
i_free = xbmc.translatePath(os.path.join(artfolder, 'free.png'))
i_sport = xbmc.translatePath(os.path.join(artfolder, 'sport.png'))
i_media = xbmc.translatePath(os.path.join(artfolder, 'media.png'))
i_series = xbmc.translatePath(os.path.join(artfolder, 'series.png'))
i_fiction = xbmc.translatePath(os.path.join(artfolder, 'fiction.png'))
i_media_60_90 = xbmc.translatePath(os.path.join(artfolder, 'media_60_90.png'))
i_music = xbmc.translatePath(os.path.join(artfolder, 'music.png'))
i_news = xbmc.translatePath(os.path.join(artfolder, 'news.png'))
i_radio = xbmc.translatePath(os.path.join(artfolder, 'radio.png'))
i_int = xbmc.translatePath(os.path.join(artfolder, 'int.png'))
i_mediaint = xbmc.translatePath(os.path.join(artfolder, 'mediaint.png'))
i_seriesint = xbmc.translatePath(os.path.join(artfolder, 'series.png'))
i_radioint = xbmc.translatePath(os.path.join(artfolder, 'radioint.png'))
i_search = xbmc.translatePath(os.path.join(artfolder, 'search.png'))
####################################
events_m3u = mysettings.getSetting('events_m3u')
free_m3u = mysettings.getSetting('free_m3u')
sport_m3u = mysettings.getSetting('sport_m3u')
media_m3u = mysettings.getSetting('media_m3u')
mediaam_m3u = mysettings.getSetting('mediaam_m3u')
medianz_m3u = mysettings.getSetting('medianz_m3u')
# seriestv_m3u = mysettings.getSetting('seriestv_m3u') #ita
series_m3u = mysettings.getSetting('series_m3u') #arch
fiction_m3u = mysettings.getSetting('fiction_m3u') 
media_60_90_m3u = mysettings.getSetting('media_60_90_m3u') 
music_m3u = mysettings.getSetting('music_m3u')
news_m3u = mysettings.getSetting('news_m3u')
radio_m3u = mysettings.getSetting('radio_m3u')
int_m3u = mysettings.getSetting('int_m3u')
mediaint_m3u = mysettings.getSetting('mediaint_m3u')
seriesint_m3u = mysettings.getSetting('seriesint_m3u')
radioint_m3u = mysettings.getSetting('radioint_m3u')


online_m3u = mysettings.getSetting('online_m3u')
####################################
log_m3u = mysettings.getSetting('log_m3u')
data = 'aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL2ZyZWVhcmhleS9pcHR2L21hc3Rlci8='
h    = base64.b64decode(data)
xml_regex = '<title>(.*?)</title>\s*<link>(.*?)</link>\s*<thumbnail>(.*?)</thumbnail>'
m3u_thumb_regex = 'tvg-logo=[\'"](.*?)[\'"]'
m3u_regex = '#(.+?),(.+)\s*(.+)\s*'
m3u_regex2 = 'EXTINF.*?,(.*?)\\n(.*?)\\n' #'#(.+?),(.+)\s*(.+)\s*'
u_tube = 'http://www.youtube.com'

def removeAccents(s):
	return ''.join((c for c in unicodedata.normalize('NFD', s.decode('utf-8')) if unicodedata.category(c) != 'Mn'))
					
def read_file(file):
    try:
        f = open(file, 'r')
        content = f.read()
        f.close()
        return content
    except:
        pass

def make_request(url):
	try:
		req = urllib2.Request(url)
		req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:19.0) Gecko/20100101 Firefox/19.0')
		response = urllib2.urlopen(req)	  
		link = response.read()
		response.close()  
		return link
	except urllib2.URLError, e:
		print 'We failed to open "%s".' % url
		if hasattr(e, 'code'):
			print 'We failed with error code - %s.' % e.code	
		if hasattr(e, 'reason'):
			print 'We failed to reach a server.'
			print 'Reason: ', e.reason

   
def main():
    add_dir('[COLOR gray][B] Version Support (changelog) [/B][/COLOR]', u_tube, 111, icon, fanart2)  
    add_dir('[B]°°° SEARCH °°°[/B]', 'searchlink', 99, i_search, f_search)
    add_dir('[COLOR yellow][B]+++ Eventi del Giorno +++[/B][/COLOR]', u_tube, 10, i_events, f_events)        
    add_dir('[COLOR yellow][B]+++ Canali Italiani Top e Regionali +++[/B][/COLOR]', u_tube, 2, i_free, f_free)   
    add_dir('[COLOR blue][B] Live Sport [/B][/COLOR]', u_tube, 3, i_sport, f_sport)  
    add_dir('[COLOR cyan][B] Film recenti ed in Sala [/B][/COLOR]', u_tube, 4, i_media, f_media)   
    add_dir('[COLOR cyan][B] Film A-M [/B][/COLOR]', u_tube, 11, i_media, f_media)   
    add_dir('[COLOR cyan][B] Film N-Z [/B][/COLOR]', u_tube, 12, i_media, f_media) 
    add_dir('[COLOR cyan][B] Film anni 60_70_80_90  [/B][/COLOR]', u_tube, 16, i_media_60_90, f_media_60_90)      
    # add_dir('[COLOR fuchsia][B] Serie Tv Italiane  [/B][/COLOR]', u_tube, 13, i_series, f_series)     
    add_dir('[COLOR fuchsia][B] Serie e Fiction Italia  [/B][/COLOR]', u_tube, 15, i_fiction, f_fiction)      
    add_dir('[COLOR fuchsia][B] Archivio Fiction e Serie Tv Italia  [/B][/COLOR]', u_tube, 14, i_series, f_series)   
    add_dir('[COLOR orange][B] Canali Musica ( Radio Tv ) [/B][/COLOR]', u_tube, 6, i_music, f_music)
    add_dir('[COLOR orange][B] Radio Italiane [/B][/COLOR]', u_tube, 7, i_radio, f_radio)     
    add_dir('[COLOR yellow][B] +++ All News +++ [/B][/COLOR]', u_tube, 17, i_news, f_news)        
    add_dir('[COLOR yellow][B] +++ International Channels +++ [/B][/COLOR]', u_tube, 8, i_int, f_int)   
    add_dir('[COLOR cyan][B] International Movie[/B][/COLOR]', u_tube, 18, i_mediaint, f_mediaint)         
    add_dir('[COLOR fuchsia][B] International Tv Series [/B][/COLOR]', u_tube, 19, i_seriesint, f_seriesint)       
    add_dir('[COLOR orange][B] International Radio[/B][/COLOR]', u_tube, 20, i_radioint, f_radioint)   
    add_dir('[COLOR yellow][B] +++ OTHER +++ [/B][/COLOR]', u_tube, 9, icon, fanart)
    # if len(local_m3u) > 0:    
        # add_dir('[COLOR orange][B] LISTA LOCAL [/B][/COLOR]', u_tube, 14, icon, fanart)
    # if len(online_xml) > 0:   
        # add_dir('[COLOR orange][B] XML ONLINE [/B][/COLOR]', u_tube, 15, icon, fanart)
    # if len(local_xml) > 0:    
        # add_dir('[COLOR orange][B] XML LOCAL [/B][/COLOR]', u_tube, 16, icon, fanart)

    
    if (  len(events_m3u) < 1 and len(free_m3u) < 1 and len(sport_m3u) < 1 and len(media_m3u) < 1 and len(mediaam_m3u) < 1 and len(medianz_m3u) < 1 and len(series_m3u) < 1 and len(media_60_90_m3u) < 1 and  len(music_m3u) < 1 and len(news_m3u) < 1 and len(radio_m3u) < 1 and len(radioint_m3u) < 1 and len (int_m3u) < 1 and len(mediaint_m3u) < 1 and len(seriesint_m3u) < 1 and len(radioint_m3u) < 1 and len(log_m3u) < 1 and len(fiction_m3u) < 1 ): #and len(seriestv_m3u) < 1 and len(online_m3u) < 1 ):
        mysettings.openSettings()
        xbmc.executebuiltin("Container.Refresh")        

def search(): 	
        try:
                keyb = xbmc.Keyboard('', 'Search :')
                keyb.doModal()
                if (keyb.isConfirmed()):
                        searchText = urllib.quote_plus(keyb.getText()).replace('+', ' ')
                if len(events_m3u) > 0:           
                        content = make_request(events_m3u)
                        match = re.compile(m3u_regex).findall(content)
                        for thumb, name, url in match:
                                if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
                                        m3u_playlist(name, url, thumb)                        
            
                if len(free_m3u) > 0:           
                        content = make_request(free_m3u)
                        match = re.compile(m3u_regex).findall(content)
                        for thumb, name, url in match:
                                if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
                                        m3u_playlist(name, url, thumb)
                    
                if len(sport_m3u) > 0:          
                        content = make_request(sport_m3u)
                        match = re.compile(m3u_regex).findall(content)          
                        for thumb, name, url in match:
                                if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
                                        m3u_playlist(name, url, thumb)                          
                    
                if len(media_m3u) > 0:          
                        content = make_request(media_m3u)
                        match = re.compile(m3u_regex).findall(content)
                        for thumb, name, url in match:
                                if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
                                        m3u_playlist(name, url, thumb)

                if len(mediaam_m3u) > 0:          
                        content = make_request(mediaam_m3u)
                        match = re.compile(m3u_regex).findall(content)
                        for thumb, name, url in match:
                                if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
                                        m3u_playlist(name, url, thumb)

                if len(medianz_m3u) > 0:          
                        content = make_request(medianz_m3u)
                        match = re.compile(m3u_regex).findall(content)
                        for thumb, name, url in match:
                                if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
                                        m3u_playlist(name, url, thumb)     
                                        
                # if len(seriestv_m3u) > 0:         
                        # content = make_request(seriestv_m3u)
                        # match = re.compile(m3u_regex).findall(content)
                        # for thumb, name, url in match:
                                # if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
                                        # m3u_playlist(name, url, thumb)   

                if len(series_m3u) > 0:         
                        content = make_request(series_m3u)
                        match = re.compile(m3u_regex).findall(content)
                        for thumb, name, url in match:
                                if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
                                        m3u_playlist(name, url, thumb)    

                if len(fiction_m3u) > 0:         
                        content = make_request(fiction_m3u)
                        match = re.compile(m3u_regex).findall(content)
                        for thumb, name, url in match:
                                if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
                                        m3u_playlist(name, url, thumb)    
                    
                if len(media_60_90_m3u) > 0:         
                        content = make_request(media_60_90_m3u)
                        match = re.compile(m3u_regex).findall(content)
                        for thumb, name, url in match:
                                if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
                                        m3u_playlist(name, url, thumb)    
       
                if len(music_m3u) > 0:          
                        content = make_request(music_m3u)
                        match = re.compile(m3u_regex).findall(content)
                        for thumb, name, url in match:
                                if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
                                        m3u_playlist(name, url, thumb)  
       
                if len(news_m3u) > 0:          
                        content = make_request(news_m3u)
                        match = re.compile(m3u_regex).findall(content)
                        for thumb, name, url in match:
                                if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
                                        m3u_playlist(name, url, thumb)  
                                        
                if len(radio_m3u) > 0:          
                        content = make_request(radio_m3u)
                        match = re.compile(m3u_regex).findall(content)          
                        for thumb, name, url in match:
                                if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
                                        m3u_playlist(name, url, thumb)   

                if len(int_m3u) > 0:    
                     content = make_request(int_m3u)
                     match = re.compile(m3u_regex).findall(content)     
                     for thumb, name, url in match:
                        if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
                           m3u_playlist(name, url, thumb)
                           
                if len(mediaint_m3u) > 0:    
                     content = make_request(mediaint_m3u)
                     match = re.compile(m3u_regex).findall(content)     
                     for thumb, name, url in match:
                        if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
                           m3u_playlist(name, url, thumb)                           
                           
                           
                if len(seriesint_m3u) > 0:    
                     content = make_request(seriesint_m3u)
                     match = re.compile(m3u_regex).findall(content)     
                     for thumb, name, url in match:
                        if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
                           m3u_playlist(name, url, thumb)
                                                      
                if len(radioint_m3u) > 0:          
                        content = make_request(radioint_m3u)
                        match = re.compile(m3u_regex).findall(content)          
                        for thumb, name, url in match:
                                if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
                                        m3u_playlist(name, url, thumb)   

                           
                # if len(online_m3u) > 0:
                     # content = make_request(online_m3u)
                     # match = re.compile(m3u_regex2).findall(content)         
                     # for name, url in match:
                         # if re.search(searchText, removeAccents(name.replace('Đ', 'D')), re.IGNORECASE):
                             # url = h + url  #m3u_playlist(name, url, thumb) 
                             # thumb= ''
                             # m3u_online2(name, url, thumb)   
                                
        except:
            pass
         
	
def m3u_log():		
	content = make_request(log_m3u)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url in match:
		try:
			m3u_playlist(name, url, thumb)
		except:
			pass
            
            
def m3u_events():
	content = make_request(events_m3u)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url in match:	
		try:
			m3u_playlist(name, url, thumb)
		except:
			pass            
            
			
def m3u_free():
	content = make_request(free_m3u)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url in match:	
		try:
			m3u_playlist(name, url, thumb)
		except:
			pass

def m3u_sport():
	content = make_request(sport_m3u)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url in match:	
		try:
			m3u_playlist(name, url, thumb)
		except:
			pass    

def m3u_media():
	content = make_request(media_m3u)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url in match:	
		try:
			m3u_playlist(name, url, thumb)
		except:
			pass  
            
def m3u_mediaal():
	content = make_request(mediaam_m3u)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url in match:	
		try:
			m3u_playlist(name, url, thumb)
		except:
			pass              
            
def m3u_mediamz():
	content = make_request(medianz_m3u)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url in match:	
		try:
			m3u_playlist(name, url, thumb)
		except:
			pass              
            
# def m3u_seriestv():
	# content = make_request(seriestv_m3u)
	# match = re.compile(m3u_regex).findall(content)
	# for thumb, name, url in match:	
		# try:
			# m3u_playlist(name, url, thumb)
		# except:
			# pass  

def m3u_series():
	content = make_request(series_m3u)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url in match:	
		try:
			m3u_playlist(name, url, thumb)
		except:
			pass  

def m3u_fiction():
	content = make_request(fiction_m3u)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url in match:	
		try:
			m3u_playlist(name, url, thumb)
		except:
			pass  
            
def m3u_media_60_90():
	content = make_request(media_60_90_m3u)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url in match:	
		try:
			m3u_playlist(name, url, thumb)
		except:
			pass  
            
def m3u_music():
	content = make_request(music_m3u)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url in match:	
		try:
			m3u_playlist(name, url, thumb)
		except:
			pass            
			
def m3u_news():
	content = make_request(news_m3u)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url in match:	
		try:
			m3u_playlist(name, url, thumb)
		except:
			pass                    
            
def m3u_radio():
	content = make_request(radio_m3u)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url in match:	
		try:
			m3u_playlist(name, url, thumb)
		except:
			pass
            
def m3u_int():
	content = make_request(int_m3u)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url in match:	
		try:
			m3u_playlist(name, url, thumb)
		except:
			pass            
            
def m3u_mediaint():
	content = make_request(mediaint_m3u)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url in match:	
		try:
			m3u_playlist(name, url, thumb)
		except:
			pass                 
            
def m3u_seriesint():
	content = make_request(seriesint_m3u)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url in match:	
		try:
			m3u_playlist(name, url, thumb)
		except:
			pass
            
            
def m3u_radioint():
	content = make_request(radioint_m3u)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url in match:	
		try:
			m3u_playlist(name, url, thumb)
		except:
			pass



def m3u_online():
        content = make_request(online_m3u)
        match = re.compile(m3u_regex2).findall(content)
        for name, url in match:         
                    url = h + url 
                    thumb= ''
                    add_dir(name, url, 22, thumb, thumb)
        xbmcplugin.endOfDirectory(plugin_handle)   

    
def m3u_online2(name, url, thumb):
                content = make_request(url)
                ##EXTINF:-1 tvg-id="Abu Dhabi Drama ARB" tvg-name="Abu Dhabi Drama ARB" tvg-language="Arabic" tvg-logo="https://i.imgur.com/7Bx66K7.jpg" group-title="",Abu Dhabi Drama
                regexcat = 'EXTINF.*?,(.*?)\\n(.*?)\\n'
                match = re.compile(regexcat,re.DOTALL).findall(content)
                for name, url in match:
                        url = url.replace(" ", "")
                        url = url.replace("\\n", "")
                        url = url.replace('\r','')
                        
                        if 'tvg-logo' in thumb:				
                            thumb = re.compile(m3u_thumb_regex).findall(str(thumb))[0].replace(' ', '%20')
                            # add_link(name, url, 1, thumb, thumb)
                        
                        name = name.replace('\r','')
                        
                        try:
                            m3u_playlist(name, url, thumb)
                        except:
                            pass
            
def m3u_local():
	content = read_file(local_m3u)
	match = re.compile(m3u_regex).findall(content)
	for thumb, name, url in match:	
		try:
			m3u_playlist(name, url, thumb)
		except:
			pass

def xml_online():			
	content = make_request(online_xml)
	match = re.compile(xml_regex).findall(content)
	for name, url, thumb in match:
		try:
			xml_playlist(name, url, thumb)
		except:
			pass
			
def xml_local():		
	content = read_file(local_xml)
	match = re.compile(xml_regex).findall(content)
	for name, url, thumb in match:	
		try:
			xml_playlist(name, url, thumb)
		except:
			pass			
			
def m3u_playlist(name, url, thumb):	
	name = re.sub('\s+', ' ', name).strip()			
	url = url.replace('"', ' ').replace('&amp;', '&').strip()
	if ('youtube.com/user/' in url) or ('youtube.com/channel/' in url) or ('youtube/user/' in url) or ('youtube/channel/' in url):
		if 'tvg-logo' in thumb:
			thumb = re.compile(m3u_thumb_regex).findall(str(thumb))[0].replace(' ', '%20')			
			add_dir(name, url, '', thumb, thumb)			
		else:	
			add_dir(name, url, '', icon, fanart)
	else:
		if 'youtube.com/watch?v=' in url:
			url = 'plugin://plugin.video.youtube/play/?video_id=%s' % (url.split('=')[-1])
		elif 'dailymotion.com/video/' in url:
			url = url.split('/')[-1].split('_')[0]
			url = 'plugin://plugin.video.dailymotion_com/?mode=playVideo&url=%s' % url	

		else:			
			url = url
		if 'tvg-logo' in thumb:				
			thumb = re.compile(m3u_thumb_regex).findall(str(thumb))[0].replace(' ', '%20')
			add_link(name, url, 1, thumb, thumb)			
		else:				
			add_link(name, url, 1, icon, fanart)
            

                

def xml_playlist(name, url, thumb):
	name = re.sub('\s+', ' ', name).strip()			
	url = url.replace('"', ' ').replace('&amp;', '&').strip()
	if ('youtube.com/user/' in url) or ('youtube.com/channel/' in url) or ('youtube/user/' in url) or ('youtube/channel/' in url):
		if len(thumb) > 0:	
			add_dir(name, url, '', thumb, thumb)			
		else:	
			add_dir(name, url, '', icon, fanart)
	else:
		if 'youtube.com/watch?v=' in url:
			url = 'plugin://plugin.video.youtube/play/?video_id=%s' % (url.split('=')[-1])
		elif 'dailymotion.com/video/' in url:
			url = url.split('/')[-1].split('_')[0]
			url = 'plugin://plugin.video.dailymotion_com/?mode=playVideo&url=%s' % url	
		else:			
			url = url
		if len(thumb) > 0:		
			add_link(name, url, 1, thumb, thumb)			
		else:			
			add_link(name, url, 1, icon, fanart)			
					
def play_video(url):
	media_url = url
	item = xbmcgui.ListItem(name, path = media_url)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
	return
			
def get_params():
	param = []
	paramstring = sys.argv[2]
	if len(paramstring)>= 2:
		params = sys.argv[2]
		cleanedparams = params.replace('?', '')
		if (params[len(params)-1] == '/'):
			params = params[0:len(params)-2]
		pairsofparams = cleanedparams.split('&')
		param = {}
		for i in range(len(pairsofparams)):
			splitparams = {}
			splitparams = pairsofparams[i].split('=')
			if (len(splitparams)) == 2:
				param[splitparams[0]] = splitparams[1]
	return param

def add_dir(name, url, mode, iconimage, fanart):
    
        u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage)
        ok = True
        liz = xbmcgui.ListItem(name, iconImage = "DefaultFolder.png", thumbnailImage = iconimage)
        liz.setInfo( type = "Video", infoLabels = { "Title": name } )
        liz.setProperty('fanart_image', fanart)
        if ('youtube.com/user/' in url) or ('youtube.com/channel/' in url) or ('youtube/user/' in url) or ('youtube/channel/' in url):
                u = 'plugin://plugin.video.youtube/%s/%s/' % (url.split( '/' )[-2], url.split( '/' )[-1])
                ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz, isFolder = True)
                return ok               
        ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz, isFolder = True)
        return ok
        
def addDirectoryItem(name, parameters={},pic=""):
    li = xbmcgui.ListItem(name,iconImage="DefaultFolder.png", thumbnailImage=pic)
    url = sys.argv[0] + '?' + urllib.urlencode(parameters)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=li, isFolder=True)
    
    
def add_link(name, url, mode, iconimage, fanart):
	u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + urllib.quote_plus(name) + "&iconimage=" + urllib.quote_plus(iconimage)	
	liz = xbmcgui.ListItem(name, iconImage = "DefaultVideo.png", thumbnailImage = iconimage)
	liz.setInfo( type = "Video", infoLabels = { "Title": name } )
	liz.setProperty('fanart_image', fanart)
	liz.setProperty('IsPlayable', 'true') 
	ok = xbmcplugin.addDirectoryItem(handle = int(sys.argv[1]), url = u, listitem = liz)  
		
params = get_params()
url = None
name = None
mode = None
iconimage = None

try:
	url = urllib.unquote_plus(params["url"])
except:
	pass
try:
	name = urllib.unquote_plus(params["name"])
except:
	pass
try:
	mode = int(params["mode"])
except:
	pass
try:
	iconimage = urllib.unquote_plus(params["iconimage"])
except:
	pass  

print "Mode: " + str(mode)
print "URL: " + str(url)
print "Name: " + str(name)
print "iconimage: " + str(iconimage)		

if mode == None or url == None or len(url) < 1:
	main()


elif mode == 1:
	play_video(url)

elif mode == 111:
	m3u_log()

elif mode == 10:
	m3u_events()

elif mode == 2:
	m3u_free()
    
elif mode == 3:
	m3u_sport()    
    
elif mode == 4:
	m3u_media()   

elif mode == 11:
	m3u_mediaal()  
    
elif mode == 12:
	m3u_mediamz()      
    
# elif mode == 13:
	# m3u_seriestv()      
    
elif mode == 14:
	m3u_series()   
    
elif mode == 15:
	m3u_fiction()     
    
elif mode == 16:
	m3u_media_60_90()     
    
elif mode == 6:
	m3u_music()
        
elif mode == 17:
	m3u_news()   

elif mode == 7:
	m3u_radio()

elif mode == 8:
	m3u_int()

elif mode == 19:
	m3u_seriesint()

elif mode == 18:
	m3u_mediaint()

elif mode == 20:
	m3u_radioint()

elif mode == 9:
    m3u_online()    
    
elif mode == 22:
    thumb = icon
    ok = m3u_online2(name, url,thumb)
    
	
elif mode == 99:
	search()
	
xbmcplugin.endOfDirectory(plugin_handle)
